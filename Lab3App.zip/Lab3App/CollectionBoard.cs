﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3App
{
    internal class CollectionBoard
    {
        public int TotalScore { get; set; }
        public int TotalValue { get; set;}
    }
}
